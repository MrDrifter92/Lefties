Restore Pack — upholstery-cleaning.html (2025-08-14)

Use this file to restore your original upholstery page content and layout.

Steps (GitHub web/phone):
1) Open /upholstery-cleaning.html in your repo.
2) Click edit.
3) Replace the entire file with the content from this restore pack, or upload this file directly to the repo root.
4) Commit to main.
5) Hard refresh your page.

No other files are changed by this pack.
